# StudyArtist 2.0 update notes

- Application ID remains `com.abhisyr.studytrack` so Android treats this as the same app.
- Version code is automatically increased by the GitHub Actions workflow.
- The APK is signed with the persistent `keystore/studyartist-update.jks` key for future updates.
- Existing `localStorage` data under `studytrack` is preserved; the app performs a safe migration and keeps a local recovery snapshot.
- Existing subjects, sessions, goals, XP, streaks, settings and backups are retained.
- New features include timer pause/resume, subject editing/colors, period-based stats, searchable/editable history, safer backup/recovery, AMOLED/font controls, and native daily reminders.

## Important first-install note

The older APKs built on ephemeral GitHub-hosted debug keys cannot be cryptographically updated by this new persistent key. If Android rejects the first 2.0 APK as an incompatible update, uninstall the old APK once, install the 2.0 APK, and all later StudyArtist updates will use the same key and should install normally without deleting app data between updates.


## v2.1 UI & Backup Fixes
- Fire emoji is shown inside each weekly streak circle.
- Subject Progress Comparison uses aligned subject/progress/time columns.
- Backup & Sync uses Android's native document saver/file picker for reliable export/import.
- Existing localStorage study data model and applicationId are preserved.
