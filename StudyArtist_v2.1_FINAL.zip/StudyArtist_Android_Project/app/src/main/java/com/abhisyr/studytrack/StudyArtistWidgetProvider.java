package com.abhisyr.studytrack;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class StudyArtistWidgetProvider extends AppWidgetProvider {
    public static void updateAll(Context context, AppWidgetManager manager, int[] ids) {
        android.content.SharedPreferences p = context.getSharedPreferences("studyartist_widget", Context.MODE_PRIVATE);
        String focus = p.getString("focus", "00:00:00");
        int streak = p.getInt("streak", 0);
        String subject = p.getString("subject", "General");

        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_studyartist);
            views.setTextViewText(R.id.widgetTitle, "StudyArtist");
            views.setTextViewText(R.id.widgetFocus, focus);
            views.setTextViewText(R.id.widgetStreak, "🔥 " + streak + " day streak");
            views.setTextViewText(R.id.widgetSubject, "📚 " + subject);

            Intent launch = new Intent(context, MainActivity.class);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(
                    context, id, launch,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            views.setOnClickPendingIntent(R.id.widgetRoot, pi);
            manager.updateAppWidget(id, views);
        }
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        updateAll(context, manager, ids);
    }

    @Override public void onEnabled(Context context) {
        super.onEnabled(context);
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        updateAll(context, manager,
                manager.getAppWidgetIds(new ComponentName(context, StudyArtistWidgetProvider.class)));
    }
}
