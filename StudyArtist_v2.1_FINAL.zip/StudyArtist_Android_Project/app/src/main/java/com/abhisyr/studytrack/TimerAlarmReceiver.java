package com.abhisyr.studytrack;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.PowerManager;

public class TimerAlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "studyartist_timer";
    private static Ringtone activeRingtone;

    @Override public void onReceive(Context context, Intent intent) {
        boolean alarmEnabled = intent.getBooleanExtra("alarm_enabled", true);
        int seconds = intent.getIntExtra("seconds", 0);
        String subject = intent.getStringExtra("subject");
        if (subject == null || subject.trim().isEmpty()) subject = "General";
        context.getSharedPreferences("studyartist_timer", Context.MODE_PRIVATE)
                .edit().putBoolean("finished", true).putInt("seconds", seconds)
                .putString("subject", subject).apply();
        if (!alarmEnabled) return;

        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock lock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "StudyArtist:TimerAlarm"
        );
        lock.acquire(15_000L);

        try {
            createChannel(context);
            Intent open = new Intent(context, MainActivity.class);
            PendingIntent contentIntent = PendingIntent.getActivity(
                    context, 7400, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            android.app.Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                    ? new android.app.Notification.Builder(context, CHANNEL_ID)
                    : new android.app.Notification.Builder(context);
            nb.setSmallIcon(com.abhisyr.studytrack.R.drawable.ic_studytrack)
              .setContentTitle("StudyArtist")
              .setContentText("Focus timer finished 🔔")
              .setAutoCancel(true)
              .setContentIntent(contentIntent)
              .setPriority(android.app.Notification.PRIORITY_MAX)
              .setCategory(android.app.Notification.CATEGORY_ALARM);

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT < 33 || nm.areNotificationsEnabled()) {
                nm.notify(7401, nb.build());
            }

            try {
                android.net.Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                activeRingtone = RingtoneManager.getRingtone(context.getApplicationContext(), uri);
                if (activeRingtone != null) {
                    if (Build.VERSION.SDK_INT >= 21) {
                        activeRingtone.setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build());
                    }
                    activeRingtone.play();
                }
            } catch (Exception ignored) {}
        } finally {
            lock.release();
        }
    }

    private void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        android.net.Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Focus Timer", NotificationManager.IMPORTANCE_HIGH
        );
        ch.setDescription("StudyArtist focus timer completion alarm");
        ch.setSound(uri, attrs);
        nm.createNotificationChannel(ch);
    }
}
