package com.abhisyr.studytrack;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.provider.MediaStore;
import android.os.Environment;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.app.AlertDialog;
import android.database.Cursor;
import android.view.Window;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int TIMER_REQUEST_CODE = 7391;
    private static final int BACKUP_EXPORT_REQUEST_CODE = 8401;
    private static final int BACKUP_IMPORT_REQUEST_CODE = 8402;
    private String pendingBackupJson;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,17,22));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(13,14,16));

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new TimerBridge(this), "StudyArtistNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1001);
        }
    }

    public static void scheduleTimer(Context context, long endAt, boolean alarmEnabled, String subject, int seconds) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, TimerAlarmReceiver.class);
        intent.putExtra("alarm_enabled", alarmEnabled);
        intent.putExtra("subject", subject == null ? "General" : subject);
        intent.putExtra("seconds", seconds);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, TIMER_REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        long trigger = Math.max(System.currentTimeMillis() + 500L, endAt);
        try {
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        }
    }

    public static void cancelTimer(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, TimerAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, TIMER_REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        am.cancel(pi);
        pi.cancel();
    }

    public class TimerBridge {
        private final Context context;
        TimerBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface
        public void scheduleTimerEnd(long endAt, boolean alarmEnabled, String subject, int seconds) {
            scheduleTimer(context, endAt, alarmEnabled, subject, seconds);
        }

        @JavascriptInterface
        public void clearFinishedTimer() {
            context.getSharedPreferences("studyartist_timer", Context.MODE_PRIVATE).edit().clear().apply();
        }

        @JavascriptInterface
        public String consumeFinishedTimer() {
            android.content.SharedPreferences p = context.getSharedPreferences("studyartist_timer", Context.MODE_PRIVATE);
            boolean done = p.getBoolean("finished", false);
            if (!done) return "";
            String subject = p.getString("subject", "General");
            int seconds = p.getInt("seconds", 0);
            p.edit().clear().apply();
            return subject.replace("\\", "\\\\").replace("\"", "\\\"") + "|" + seconds;
        }

        @JavascriptInterface
        public void cancelTimerEnd() {
            cancelTimer(context);
        }

        @JavascriptInterface
        public void scheduleDailyReminder(String time) {
            ReminderReceiver.scheduleDailyReminder(context, time);
        }

        @JavascriptInterface
        public void cancelDailyReminder() {
            ReminderReceiver.cancelDailyReminder(context);
        }

        @JavascriptInterface
        public void exportBackup(String json) {
            if (json == null || json.trim().isEmpty()) return;
            saveBackupToStudyArtistFolder(json);
        }

        @JavascriptInterface
        public void syncWidgetData(String focus, int streak, String subject) {
            try {
                context.getSharedPreferences("studyartist_widget", Context.MODE_PRIVATE)
                        .edit()
                        .putString("focus", focus == null ? "00:00:00" : focus)
                        .putInt("streak", Math.max(0, streak))
                        .putString("subject", subject == null ? "General" : subject)
                        .apply();
                android.appwidget.AppWidgetManager manager = android.appwidget.AppWidgetManager.getInstance(context);
                android.content.ComponentName component = new android.content.ComponentName(context, StudyArtistWidgetProvider.class);
                int[] ids = manager.getAppWidgetIds(component);
                if (ids != null && ids.length > 0) {
                    StudyArtistWidgetProvider.updateAll(context, manager, ids);
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void exportTextFile(String fileName, String content, String mimeType) {
            if (fileName == null || fileName.trim().isEmpty() || content == null) return;
            saveReportFile(fileName, content, mimeType == null ? "text/plain" : mimeType);
        }

        @JavascriptInterface
        public void exportPdfReport(String title, String body) {
            if (title == null) title = "StudyArtist Report";
            if (body == null) body = "";
            savePdfReport(title, body);
        }

        @JavascriptInterface
        public void importBackup() {
            showBackupChooser();
        }

        @JavascriptInterface
        public void openExactAlarmSettings() {
            if (Build.VERSION.SDK_INT >= 31) {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    i.setData(Uri.parse("package:" + context.getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(i);
                } catch (Exception ignored) {}
            }
        }
    }

    private String localDateForFile() {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
        return f.format(new java.util.Date());
    }

    private static final String BACKUP_RELATIVE_PATH = Environment.DIRECTORY_DOCUMENTS + "/StudyArtist/Backups/";
    private static final String BACKUP_FILE_NAME = "studyartist-backup.json";
    private static final String LEGACY_BACKUP_PREFIX = "studyartist-backup-";

    private Uri findBackupUri(String displayName) {
        Uri collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        String[] projection = { MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME };
        String selection = MediaStore.Files.FileColumns.RELATIVE_PATH + "=? AND " + MediaStore.Files.FileColumns.DISPLAY_NAME + "=?";
        String[] args = { BACKUP_RELATIVE_PATH, displayName };
        try (Cursor c = getContentResolver().query(collection, projection, selection, args, null)) {
            if (c != null && c.moveToFirst()) {
                long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID));
                return Uri.withAppendedPath(collection, String.valueOf(id));
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void deleteLegacyBackups() {
        if (Build.VERSION.SDK_INT >= 29) {
            Uri collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            String[] projection = { MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME };
            String selection = MediaStore.Files.FileColumns.RELATIVE_PATH + "=?";
            String[] args = { BACKUP_RELATIVE_PATH };
            try (Cursor c = getContentResolver().query(collection, projection, selection, args, null)) {
                if (c != null) {
                    int idCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);
                    int nameCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME);
                    while (c.moveToNext()) {
                        String name = c.getString(nameCol);
                        if (name != null && name.toLowerCase(java.util.Locale.US).endsWith(".json") &&
                                name.startsWith(LEGACY_BACKUP_PREFIX) && !BACKUP_FILE_NAME.equals(name)) {
                            long id = c.getLong(idCol);
                            getContentResolver().delete(Uri.withAppendedPath(collection, String.valueOf(id)), null, null);
                        }
                    }
                }
            } catch (Exception ignored) {}
        } else {
            java.io.File dir = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "StudyArtist/Backups");
            java.io.File[] files = dir.listFiles((d, name) -> name.toLowerCase(java.util.Locale.US).endsWith(".json") && name.startsWith(LEGACY_BACKUP_PREFIX) && !BACKUP_FILE_NAME.equals(name));
            if (files != null) for (java.io.File file : files) try { file.delete(); } catch (Exception ignored) {}
        }
    }

    private void saveBackupToStudyArtistFolder(String json) {
        try {
            byte[] data = json.getBytes(StandardCharsets.UTF_8);
            if (Build.VERSION.SDK_INT >= 29) {
                Uri uri = findBackupUri(BACKUP_FILE_NAME);
                if (uri == null) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Files.FileColumns.DISPLAY_NAME, BACKUP_FILE_NAME);
                    values.put(MediaStore.Files.FileColumns.MIME_TYPE, "application/json");
                    values.put(MediaStore.Files.FileColumns.RELATIVE_PATH, BACKUP_RELATIVE_PATH);
                    Uri collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                    uri = getContentResolver().insert(collection, values);
                } else {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Files.FileColumns.MIME_TYPE, "application/json");
                    getContentResolver().update(uri, values, null, null);
                }
                if (uri == null) throw new java.io.IOException("Unable to create backup file");
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new java.io.IOException("No output stream");
                    out.write(data);
                    out.flush();
                }
                deleteLegacyBackups();
            } else {
                java.io.File dir = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "StudyArtist/Backups");
                if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("Unable to create backup folder");
                java.io.File file = new java.io.File(dir, BACKUP_FILE_NAME);
                try (OutputStream out = new java.io.FileOutputStream(file, false)) {
                    out.write(data);
                    out.flush();
                }
                deleteLegacyBackups();
            }
            Toast.makeText(this, "Backup saved in Documents/StudyArtist/Backups ✓", Toast.LENGTH_LONG).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "Storage permission is required for backup", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Backup export failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void showBackupChooser() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                final java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
                final java.util.ArrayList<String> names = new java.util.ArrayList<>();
                Uri collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                String[] projection = {
                        MediaStore.Files.FileColumns._ID,
                        MediaStore.Files.FileColumns.DISPLAY_NAME,
                        MediaStore.Files.FileColumns.RELATIVE_PATH,
                        MediaStore.Files.FileColumns.MIME_TYPE
                };
                try (Cursor c = getContentResolver().query(collection, projection, null, null,
                        MediaStore.Files.FileColumns.DATE_MODIFIED + " DESC")) {
                    if (c != null) {
                        int idCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);
                        int nameCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME);
                        int pathCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.RELATIVE_PATH);
                        int mimeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE);
                        while (c.moveToNext()) {
                            String name = c.getString(nameCol);
                            String path = c.getString(pathCol);
                            String mime = c.getString(mimeCol);
                            if (name == null || !name.toLowerCase(java.util.Locale.US).endsWith(".json")) continue;
                            if (path == null || !path.equalsIgnoreCase(BACKUP_RELATIVE_PATH)) continue;
                            if (mime != null && !mime.isEmpty() && !"application/json".equalsIgnoreCase(mime)
                                    && !"text/plain".equalsIgnoreCase(mime)) continue;
                            long id = c.getLong(idCol);
                            uris.add(Uri.withAppendedPath(collection, String.valueOf(id)));
                            names.add(name);
                        }
                    }
                }

                // Fallback: direct lookup of the canonical backup if MediaStore's Files query
                // does not expose the relative path on a particular OEM.
                if (names.isEmpty()) {
                    Uri canonical = findBackupUri(BACKUP_FILE_NAME);
                    if (canonical != null) {
                        uris.add(canonical);
                        names.add(BACKUP_FILE_NAME);
                    }
                }

                if (names.isEmpty()) {
                    Toast.makeText(this, "No StudyArtist backups found in Documents/StudyArtist/Backups", Toast.LENGTH_LONG).show();
                    return;
                }

                new AlertDialog.Builder(this)
                        .setTitle("Import StudyArtist Backup")
                        .setItems(names.toArray(new String[0]), (dialog, which) -> readBackupUri(uris.get(which)))
                        .setNegativeButton("Cancel", null)
                        .show();
            } else {
                java.io.File dir = new java.io.File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                        "StudyArtist/Backups"
                );
                java.io.File[] files = dir.listFiles((d, name) ->
                        name.toLowerCase(java.util.Locale.US).endsWith(".json"));
                if (files == null || files.length == 0) {
                    Toast.makeText(this, "No StudyArtist backups found in Documents/StudyArtist/Backups", Toast.LENGTH_LONG).show();
                    return;
                }
                java.util.Arrays.sort(files, (a,b) -> Long.compare(b.lastModified(), a.lastModified()));
                String[] names = new String[files.length];
                for (int i=0;i<files.length;i++) names[i]=files[i].getName();
                new AlertDialog.Builder(this)
                        .setTitle("Import StudyArtist Backup")
                        .setItems(names, (dialog, which) -> readBackupFile(files[which]))
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Backup import failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveReportFile(String fileName, String content, String mimeType) {
        try {
            byte[] data = content.getBytes(StandardCharsets.UTF_8);
            final String reportPath = Environment.DIRECTORY_DOCUMENTS + "/StudyArtist/Reports/";
            if (Build.VERSION.SDK_INT >= 29) {
                Uri collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Files.FileColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.Files.FileColumns.MIME_TYPE, mimeType);
                values.put(MediaStore.Files.FileColumns.RELATIVE_PATH, reportPath);
                Uri uri = getContentResolver().insert(collection, values);
                if (uri == null) throw new java.io.IOException("Unable to create report");
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new java.io.IOException("No output stream");
                    out.write(data);
                    out.flush();
                }
            } else {
                java.io.File dir = new java.io.File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                        "StudyArtist/Reports"
                );
                if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("Unable to create report folder");
                try (OutputStream out = new java.io.FileOutputStream(new java.io.File(dir, fileName), false)) {
                    out.write(data);
                    out.flush();
                }
            }
            Toast.makeText(this, "Report saved in Documents/StudyArtist/Reports ✓", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Report export failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void savePdfReport(String title, String body) {
        try {
            android.graphics.pdf.PdfDocument doc = new android.graphics.pdf.PdfDocument();
            android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            paint.setTextSize(11f);
            android.graphics.Paint titlePaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            titlePaint.setTextSize(18f);
            titlePaint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);

            java.util.ArrayList<String> lines = new java.util.ArrayList<>();
            for (String paragraph : body.split("\\\\n")) {
                String remaining = paragraph == null ? "" : paragraph;
                while (remaining.length() > 90) {
                    lines.add(remaining.substring(0, 90));
                    remaining = remaining.substring(90);
                }
                lines.add(remaining);
            }

            int pageNo = 1;
            android.graphics.pdf.PdfDocument.Page page = doc.startPage(
                    new android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, pageNo).create()
            );
            android.graphics.Canvas canvas = page.getCanvas();
            float y = 50f;
            canvas.drawText(title, 40f, y, titlePaint);
            y += 28f;
            for (String line : lines) {
                if (y > 800f) {
                    doc.finishPage(page);
                    pageNo++;
                    page = doc.startPage(new android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, pageNo).create());
                    canvas = page.getCanvas();
                    y = 45f;
                }
                canvas.drawText(line, 40f, y, paint);
                y += 17f;
            }
            doc.finishPage(page);

            String safe = title.replaceAll("[^A-Za-z0-9_-]", "_");
            String fileName = safe + "-" + localDateForFile() + ".pdf";
            final String reportPath = Environment.DIRECTORY_DOCUMENTS + "/StudyArtist/Reports/";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Files.FileColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.Files.FileColumns.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Files.FileColumns.RELATIVE_PATH, reportPath);
                Uri collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri uri = getContentResolver().insert(collection, values);
                if (uri == null) throw new java.io.IOException("Unable to create PDF");
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new java.io.IOException("No PDF output");
                    doc.writeTo(out);
                }
            } else {
                java.io.File dir = new java.io.File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                        "StudyArtist/Reports"
                );
                if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("Unable to create PDF folder");
                try (OutputStream out = new java.io.FileOutputStream(new java.io.File(dir, fileName), false)) {
                    doc.writeTo(out);
                }
            }
            doc.close();
            Toast.makeText(this, "PDF report saved in Documents/StudyArtist/Reports ✓", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "PDF export failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void readBackupUri(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new java.io.IOException("No input stream");
            byte[] buffer = new byte[8192]; int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            deliverBackupJson(out.toString(StandardCharsets.UTF_8.name()));
        } catch (Exception e) {
            Toast.makeText(this, "Backup import failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void readBackupFile(java.io.File file) {
        try (InputStream in = new java.io.FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            deliverBackupJson(out.toString(StandardCharsets.UTF_8.name()));
        } catch (Exception e) {
            Toast.makeText(this, "Backup import failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void deliverBackupJson(String json) {
        try {
            new JSONObject(json);
            String js = "window.StudyArtistImportBackup(" + JSONObject.quote(json) + ")";
            webView.post(() -> webView.evaluateJavascript(js, null));
        } catch (Exception e) {
            Toast.makeText(this, "Invalid backup file", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.removeJavascriptInterface("StudyArtistNative");
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
