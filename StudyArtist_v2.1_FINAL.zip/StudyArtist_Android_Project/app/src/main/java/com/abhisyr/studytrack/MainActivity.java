package com.abhisyr.studytrack;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int TIMER_REQUEST_CODE = 7391;
    private static final int BACKUP_EXPORT_REQUEST_CODE = 8401;
    private static final int BACKUP_IMPORT_REQUEST_CODE = 8402;
    private String pendingBackupJson;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,17,22));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(13,14,16));

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new TimerBridge(this), "StudyArtistNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1001);
        }
    }

    public static void scheduleTimer(Context context, long endAt, boolean alarmEnabled, String subject, int seconds) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, TimerAlarmReceiver.class);
        intent.putExtra("alarm_enabled", alarmEnabled);
        intent.putExtra("subject", subject == null ? "General" : subject);
        intent.putExtra("seconds", seconds);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, TIMER_REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        long trigger = Math.max(System.currentTimeMillis() + 500L, endAt);
        try {
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        }
    }

    public static void cancelTimer(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, TimerAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, TIMER_REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        am.cancel(pi);
        pi.cancel();
    }

    public class TimerBridge {
        private final Context context;
        TimerBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface
        public void scheduleTimerEnd(long endAt, boolean alarmEnabled, String subject, int seconds) {
            scheduleTimer(context, endAt, alarmEnabled, subject, seconds);
        }

        @JavascriptInterface
        public String consumeFinishedTimer() {
            android.content.SharedPreferences p = context.getSharedPreferences("studyartist_timer", Context.MODE_PRIVATE);
            boolean done = p.getBoolean("finished", false);
            if (!done) return "";
            String subject = p.getString("subject", "General");
            int seconds = p.getInt("seconds", 0);
            p.edit().clear().apply();
            return subject.replace("\\", "\\\\").replace("\"", "\\\"") + "|" + seconds;
        }

        @JavascriptInterface
        public void cancelTimerEnd() {
            cancelTimer(context);
        }

        @JavascriptInterface
        public void scheduleDailyReminder(String time) {
            ReminderReceiver.scheduleDailyReminder(context, time);
        }

        @JavascriptInterface
        public void cancelDailyReminder() {
            ReminderReceiver.cancelDailyReminder(context);
        }

        @JavascriptInterface
        public void exportBackup(String json) {
            if (json == null || json.trim().isEmpty()) return;
            pendingBackupJson = json;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "studyartist-backup-" + localDateForFile() + ".json");
            try {
                startActivityForResult(intent, BACKUP_EXPORT_REQUEST_CODE);
            } catch (Exception e) {
                pendingBackupJson = null;
                Toast.makeText(MainActivity.this, "Unable to open file saver", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void importBackup() {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            try {
                startActivityForResult(intent, BACKUP_IMPORT_REQUEST_CODE);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Unable to open file picker", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void openExactAlarmSettings() {
            if (Build.VERSION.SDK_INT >= 31) {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    i.setData(Uri.parse("package:" + context.getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(i);
                } catch (Exception ignored) {}
            }
        }
    }

    private String localDateForFile() {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
        return f.format(new java.util.Date());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == BACKUP_EXPORT_REQUEST_CODE) pendingBackupJson = null;
            return;
        }
        Uri uri = data.getData();
        if (requestCode == BACKUP_EXPORT_REQUEST_CODE) {
            String json = pendingBackupJson;
            pendingBackupJson = null;
            if (json == null) return;
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new java.io.IOException("No output stream");
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
                Toast.makeText(this, "Backup saved ✓", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Backup export failed", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == BACKUP_IMPORT_REQUEST_CODE) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                if (in == null) throw new java.io.IOException("No input stream");
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                String json = out.toString(StandardCharsets.UTF_8.name());
                String js = "window.StudyArtistImportBackup(" + JSONObject.quote(json) + ")";
                webView.post(() -> webView.evaluateJavascript(js, null));
            } catch (Exception e) {
                Toast.makeText(this, "Backup import failed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.removeJavascriptInterface("StudyArtistNative");
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
