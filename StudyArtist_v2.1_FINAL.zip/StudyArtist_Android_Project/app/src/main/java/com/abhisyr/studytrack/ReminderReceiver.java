package com.abhisyr.studytrack;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "studyartist_reminders";
    private static final int REQUEST_CODE = 8402;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            boolean enabled = context.getSharedPreferences("studyartist_reminder", Context.MODE_PRIVATE)
                    .getBoolean("enabled", false);
            if (enabled) {
                String time = context.getSharedPreferences("studyartist_reminder", Context.MODE_PRIVATE)
                        .getString("time", "20:00");
                scheduleDailyReminder(context, time);
            }
            return;
        }
        createChannel(context);
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context, 8403, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 33 && !nm.areNotificationsEnabled()) return;

        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(context, CHANNEL_ID)
                : new android.app.Notification.Builder(context);
        b.setSmallIcon(R.drawable.ic_studytrack)
                .setContentTitle("StudyArtist")
                .setContentText("Time for a study session 📚")
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setPriority(android.app.Notification.PRIORITY_DEFAULT);
        nm.notify(8404, b.build());

        String time = context.getSharedPreferences("studyartist_reminder", Context.MODE_PRIVATE)
                .getString("time", "20:00");
        scheduleDailyReminder(context, time);
    }

    public static void scheduleDailyReminder(Context context, String time) {
        int hour = 20, minute = 0;
        try {
            String[] p = (time == null ? "20:00" : time).split(":");
            hour = Math.max(0, Math.min(23, Integer.parseInt(p[0])));
            minute = Math.max(0, Math.min(59, Integer.parseInt(p[1])));
        } catch (Exception ignored) {}

        context.getSharedPreferences("studyartist_reminder", Context.MODE_PRIVATE)
                .edit().putString("time", String.format("%02d:%02d", hour, minute)).putBoolean("enabled", true).apply();

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(context, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, REQUEST_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, hour);
        next.set(Calendar.MINUTE, minute);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_YEAR, 1);

        try {
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
            } else if (Build.VERSION.SDK_INT >= 19) {
                am.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
            } else {
                am.setRepeating(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
            }
        } catch (SecurityException e) {
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
        }
    }

    public static void cancelDailyReminder(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(context, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, REQUEST_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        am.cancel(pi);
        pi.cancel();
        context.getSharedPreferences("studyartist_reminder", Context.MODE_PRIVATE)
                .edit().putBoolean("enabled", false).apply();
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Study Reminders", NotificationManager.IMPORTANCE_DEFAULT
        );
        ch.setDescription("Daily StudyArtist study reminders");
        nm.createNotificationChannel(ch);
    }
}
